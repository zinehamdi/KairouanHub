KairouanHub Static Home Page
===========================

This is a minimal static landing page for deployment to Hostinger.

- index.html: Main page with floating window "Coming Soon انشاءالله"
- favicon.ico: Place your favicon here (copy from public/favicon.ico)

How to deploy:
1. Upload the contents of this zip to your Hostinger public_html directory.
2. Your site will show a floating "Coming Soon" window.

No backend or Laravel required.
